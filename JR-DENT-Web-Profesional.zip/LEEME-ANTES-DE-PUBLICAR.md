# JR DENT — Sitio web renovado

## Qué contiene
- **Inicio:** portada, seis categorías, las dos promociones, productos destacados, presentación comercial y sección de servicio técnico.
- **Catálogo:** 32 referencias iniciales, con 30 artículos del catálogo actual más 2 promociones; filtro por categorías, búsqueda y ordenamiento.
- **Producto individual:** ficha, selección de variantes en promociones, cantidades, botones de carrito y consulta.
- **Carrito:** gestión de cantidades, eliminación y totales en S/. Se conserva localmente en el navegador mediante `localStorage`.
- **Finalizar compra:** formulario y **pedido preparado para WhatsApp** al teléfono +51 994 110 557. No se cobran tarjetas, no se confirma stock ni se registra un pedido pagado automáticamente.
- **Servicio técnico:** diseño diferente, presentación de la empresa, pasos y formulario de diagnóstico (nombre, teléfono, equipo, marca, modelo, problema, antigüedad de falla y modalidad). Genera un mensaje para WhatsApp; **el cliente debe pulsar «Enviar» dentro de WhatsApp**.
- **Cuenta:** registro, inicio de sesión, Google, recuperación de contraseña y cierre de sesión mediante el **Firebase Authentication que figuraba en la página original**. El carrito no se sincroniza entre equipos. No se implementó historial de pedidos en servidor.
- **Contacto:** tus dos direcciones de JR DENT, botón de WhatsApp, Instagram, TikTok y buscador de la cuenta en Facebook.
- **Responsivo:** adaptable a celular, tablet y computadora.

## Archivos incluidos
`index.html` — punto de entrada.
`styles.css` — estilos de todo el sitio.
`catalogo.js` — productos, categorías, precios y referencias de fotografías.
`app.js` — navegación, búsqueda, promociones, carrito, formularios y páginas.
`auth.js` — Firebase Authentication.
`favicon.svg` — ícono de pestaña.
`assets/promo-turbinas.webp` y `assets/promo-micromotores.webp` — imágenes suministradas, optimizadas para la web.

## Publicar en tu página actual de GitHub Pages
Repositorio: https://github.com/jonatan098732/JR-Dent

1. **Haz una copia de seguridad** de tu `index.html` original antes de reemplazarlo.
2. En la rama `main`, sube al directorio raíz: `index.html`, `styles.css`, `catalogo.js`, `app.js`, `auth.js` y `favicon.svg`.
3. Sube ambas fotografías a **`assets/`**, conservando los nombres exactos.
4. **NO BORRES las imágenes JPG antiguas de GitHub:** las fichas del nuevo catálogo siguen utilizándolas mediante la dirección pública de tu página anterior (`https://jonatan098732.github.io/JR-Dent/`). Las fotografías de `mano5.jpg` y `mano6.jpg` **no aparecen en el repositorio público**; estas dos fichas muestran un marcador de fotografía pendiente en vez de una imagen inventada.
5. Abre `https://jonatan098732.github.io/JR-Dent/` cuando GitHub Pages haya publicado los archivos y comprueba el catálogo, WhatsApp, navegación y las cuentas en un dispositivo móvil.

**Importante:** No hemos modificado ni publicado nada en tu cuenta de GitHub. Esta es una versión para subir a tu repositorio cuando la apruebes.

## Firebase — verificar antes de permitir registros reales
La web original incluía el proyecto Firebase `jr-dent`, y la nueva versión conserva esa configuración pública del cliente para usar cuentas reales. **No podemos comprobar desde aquí los permisos, el dominio autorizado ni los proveedores activados de tu consola Firebase.**

- En Firebase Console → Authentication → Sign-in method, confirma **Email/Password**. Si quieres entrar con Google, activa también **Google**.
- En Firebase Console → Authentication → Settings → Authorized domains, comprueba `jonatan098732.github.io`.
- Prueba en la página publicada crear una cuenta de prueba, iniciar sesión, salir y restablecer contraseña.
- **Nunca pongas credenciales privadas, contraseñas administrativas o claves de servicio en el repositorio público.** La configuración pública de Firebase aquí es diferente de una clave privada de servidor.
- Si más adelante habilitas Firestore para usuarios, pedidos o almacenamiento, establece reglas estrictas para impedir que otro usuario acceda a los datos ajenos. Esta versión no escribe pedidos ni perfiles en Firestore.

## Pendiente de confirmar antes de vender
- Los **precios del catálogo** proceden de la web pública previa (consulta del 26/10/2026) y pueden no corresponder al stock o tarifas actuales. Confírmalos en `catalogo.js`.
- **Promoción S/ 500:** confirmar modelos de las dos piezas de mano NSK/KaVo, combinaciones, stock, duración de la oferta y condiciones de garantía.
- **Promoción S/ 290:** confirmar si corresponde al micromotor completo, a las piezas de baja velocidad o a unidades individuales de la foto, así como marcas y colores. El texto está redactado prudentemente y solicita confirmación.
- **Fotografías pendientes:** `Pieza recta NSK` y `Micromotor Marathon`; se señalan en el catálogo y deben sustituirse por fotos reales.
- **Dirección de Facebook:** como proporcionaste solo el nombre «JR Dent Fernando Rios Villacorta», el enlace abre una búsqueda en Facebook, NO una página oficial verificada. Sustituir cuando se facilite URL exacta.
- **Horario:** se incluyó 9:00 a. m. – 6:00 p. m.; no se inventaron días de atención.
- **Correo electrónico:** no se incluyó porque no fue proporcionado. El formulario de servicio funciona por WhatsApp, sin correo automático.
- Revisa e incorpora políticas reales de cambios/devoluciones, tratamiento de datos, garantías, envíos y formalidades comerciales antes de habilitar pagos en línea.

## Cómo ver la web en tu computadora
Abre `index.html` en un navegador para ver gran parte del diseño y la navegación. Para probar **Firebase**, lo ideal es publicarla o abrirla mediante un servidor local, ya que módulos externos pueden bloquearse cuando se abre con `file://`.

Opcional, si tienes Python: abre una terminal dentro de esta carpeta y ejecuta `python -m http.server 8000`. Después visita `http://localhost:8000`.

## Personalizar precios, productos y fotografías
En `catalogo.js`, cada producto se escribe con:
```js
{id:'codigo-unico',name:'Nombre',category:'Piezas de mano',brand:'NSK',price:260,img:'mano1.jpg',description:'Descripción comercial'}
```
La propiedad `img` admite el nombre de una foto existente en el repositorio o una ruta local como `assets/mi-foto.webp`. Si usas una nueva foto, súbela primero.

### Seguridad comercial
La web **NO acepta pagos ni guarda tarjetas**. El botón de comprar redacta un mensaje de WhatsApp y el cliente lo envía manualmente. No afirma que un pedido esté recibido ni pagado sin confirmación del negocio.
